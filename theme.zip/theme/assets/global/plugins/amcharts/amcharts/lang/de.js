AmCharts.translations.de = {
	"monthNames": ["Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember"],
	"shortMonthNames": ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"],
	"dayNames": ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"],
	"shortDayNames": ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"],
	"zoomOutText": "Alle anzeigen",
	"fromText": "Von:",
	"toText":"Bis:",
	"periodsText":"Ansicht:",
	"selectText":"Auswahl:",
	"comboBoxSelectText":"Auswahl...",
	"compareText":"Vergleichen mit:"
}